#!/usr/bin/env bash
# Compatibility launcher: preserve the checkout's research configuration.
set -euo pipefail
code_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export WORKFLOW_CODE_DIR="$code_dir"
export WORKFLOW_PACKAGE=1
export WORKFLOW_BATCH_CONFIG="${WORKFLOW_CONFIG:-$code_dir/workflow.conf}"
export PYTHONPATH="$code_dir/src${PYTHONPATH:+:$PYTHONPATH}"
exec bash "$code_dir/src/vasp_workflow/resources/batch_workflow.sh" "$@"
