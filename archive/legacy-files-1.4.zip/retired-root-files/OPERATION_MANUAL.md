# Operation manual

The maintained [user manual](docs/user_manual.md) describes installation and operation
of version 1.4.1. See the [physics reference](docs/physics_reference.md) for scientific
background and the [developer guide](docs/developer_guide.md) for source organization.
