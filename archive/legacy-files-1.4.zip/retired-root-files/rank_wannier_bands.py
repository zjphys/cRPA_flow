#!/usr/bin/env python3
"""Compatibility entry point; maintained implementation lives in src/vasp_workflow."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from vasp_workflow import rank_wannier_bands as _implementation

if __name__ == "__main__":
    raise SystemExit(_implementation.main())
else:
    sys.modules[__name__] = _implementation
