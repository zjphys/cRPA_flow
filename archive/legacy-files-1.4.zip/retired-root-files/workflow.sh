#!/usr/bin/env bash
# Compatibility launcher: the legacy default root is the checkout directory.
set -euo pipefail
code_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export WORKFLOW_ROOT="${WORKFLOW_ROOT:-$code_dir}"
export WORKFLOW_CODE_DIR="$code_dir"
export WORKFLOW_PACKAGE=1
export PYTHONPATH="$code_dir/src${PYTHONPATH:+:$PYTHONPATH}"
exec bash "$code_dir/src/vasp_workflow/resources/workflow.sh" "$@"
