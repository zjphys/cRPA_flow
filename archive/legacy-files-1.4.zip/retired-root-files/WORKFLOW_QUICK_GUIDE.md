# Workflow quick guide

See the maintained [command quick guide](docs/quickstart.md) and
[installation instructions](docs/installation.md).
