#!/usr/bin/env python3
"""Compatibility entry point; maintained implementation lives in src/vasp_workflow."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from vasp_workflow import prepare_crpa as _implementation

if __name__ == "__main__":
    if not any(arg == "--root" or arg.startswith("--root=") for arg in sys.argv[1:]):
        sys.argv.extend(["--root", str(Path(__file__).resolve().parent)])
    raise SystemExit(_implementation.main())
else:
    sys.modules[__name__] = _implementation
